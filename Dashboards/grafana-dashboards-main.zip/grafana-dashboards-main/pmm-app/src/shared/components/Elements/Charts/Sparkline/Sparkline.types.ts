export interface PolygonChartInterface {
  data?: any;
  ykey?: any;
  width?: any;
  height?: any;
  metricName?: any;
  color?: any;
  margin?: number;
}
