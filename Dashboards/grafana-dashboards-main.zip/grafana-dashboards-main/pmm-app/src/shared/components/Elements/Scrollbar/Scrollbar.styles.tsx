import { css } from '@emotion/css';

export const styles = {
  scrollbar: css`
    .simplebar-scrollbar::before {
      background: white !important;
    }
  `,
};
