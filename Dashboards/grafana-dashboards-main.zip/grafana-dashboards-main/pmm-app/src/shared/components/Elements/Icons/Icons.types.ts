import React from 'react';

export interface SvgProps extends React.HTMLAttributes<SVGElement> {
  className?: string;
}
