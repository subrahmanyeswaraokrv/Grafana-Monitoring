export default jest.fn(() => ['metrics-resolution', jest.fn()]);
