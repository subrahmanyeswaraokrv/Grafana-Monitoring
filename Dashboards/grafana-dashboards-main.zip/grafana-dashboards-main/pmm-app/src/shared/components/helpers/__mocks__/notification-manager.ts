export const showSuccessNotification = jest.fn();

export const showWarningNotification = jest.fn();

export const showErrorNotification = jest.fn();
