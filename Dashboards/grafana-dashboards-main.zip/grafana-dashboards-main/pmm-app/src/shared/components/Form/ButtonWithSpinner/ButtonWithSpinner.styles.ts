import { css } from '@emotion/css';

export const Button = css`
  align-items: center;
  display: flex;
  flex-direction: column;
  width: 100%;
`;
