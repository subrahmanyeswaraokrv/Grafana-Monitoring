export const dataTestId = (selector: string) => `[data-testid="${selector}"]`;
