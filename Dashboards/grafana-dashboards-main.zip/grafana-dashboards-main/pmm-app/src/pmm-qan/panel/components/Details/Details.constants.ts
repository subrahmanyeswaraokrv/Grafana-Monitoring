export const TabKeys = {
  details: 'details',
  examples: 'examples',
  explain: 'explain',
  tables: 'tables',
  plan: 'plan',
};

export const OVERLAY_LOADER_SIZE = 35;
