export const Messages = {
  follow: 'Please follow the example below',
  replace: 'Replace placeholders and submit to get explanation.',
  submit: 'Explain',
};
