import ExplainPlaceholders from './ExplainPlaceholders';

export default ExplainPlaceholders;
