export const Messages = {
  planId: 'Plan ID:',
  noPlan: 'No plan found',
};
