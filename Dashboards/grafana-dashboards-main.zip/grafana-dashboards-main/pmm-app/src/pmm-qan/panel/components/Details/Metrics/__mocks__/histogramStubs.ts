export const histApiStub = {
  histogram_items: [
    {
      range: '(0 - 3)',
      frequency: 23552,
    },
    {
      range: '(3 - 10)',
      frequency: 31,
    },
  ],
};
