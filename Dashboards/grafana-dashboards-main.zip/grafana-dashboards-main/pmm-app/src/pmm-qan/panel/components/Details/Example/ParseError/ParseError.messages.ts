export const Messages = {
  parsingFailed:
    'Example query is not successfully parsed due to the max query length limit that you set or set by default.',
};
