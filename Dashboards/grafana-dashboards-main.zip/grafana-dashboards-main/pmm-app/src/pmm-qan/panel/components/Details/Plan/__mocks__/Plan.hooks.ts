import { planStub } from './planStubs';

export const usePlan = () => [planStub, false];
