import PlaceholdersForm from './PlaceholdersForm';

export default PlaceholdersForm;
