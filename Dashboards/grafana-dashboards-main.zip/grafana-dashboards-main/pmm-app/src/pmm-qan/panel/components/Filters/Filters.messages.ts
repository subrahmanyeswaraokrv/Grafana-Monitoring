export const Messages = {
  buttons: {
    reset: 'Reset All',
    showSelected: 'Show Selected',
    showAll: 'Show all',
  },
};
