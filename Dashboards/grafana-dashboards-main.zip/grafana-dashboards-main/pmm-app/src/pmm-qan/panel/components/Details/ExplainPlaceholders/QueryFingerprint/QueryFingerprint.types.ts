export interface QueryFingerprintProps {
  placeholders: string[];
  fingerprint: string;
}
