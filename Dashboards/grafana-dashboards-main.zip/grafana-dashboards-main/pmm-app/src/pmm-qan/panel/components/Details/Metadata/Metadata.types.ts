// Interface for the line in metadata table
export interface LineMetadata {
  name: string;
  value: string;
}
