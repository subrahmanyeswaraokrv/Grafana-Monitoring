export const MAIN_METRIC_MIN_WIDTH = 400;
export const COLUMN_WIDTH = 250;
export const ROW_NUMBER_COLUMN_WIDTH = 40;
export const FIXED_COLUMN_WIDTH = 144;
export const SCROLLBAR_WIDTH = 2;
