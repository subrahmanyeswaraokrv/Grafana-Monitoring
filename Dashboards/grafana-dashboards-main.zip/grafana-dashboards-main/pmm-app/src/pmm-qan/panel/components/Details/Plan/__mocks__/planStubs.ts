export const planStub = {
  id: '762196547',
  plan: 'SELECT * FROM pg_stat_monitor;',
};
