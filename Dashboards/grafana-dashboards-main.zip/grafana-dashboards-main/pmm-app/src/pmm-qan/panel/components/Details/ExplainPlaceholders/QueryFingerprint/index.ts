import QueryFingerprint from './QueryFingerprint';

export default QueryFingerprint;
